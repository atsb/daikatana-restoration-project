///////////////////////////////////////////////////////////////////////////////
//	gl_icons.cpp
//
//	Routines for displaying onscreen icons
//
///////////////////////////////////////////////////////////////////////////////

#include	"gl_local.h"
#include	"gl_protex.h"
#include  "p_user.h"


///////////////////////////////////////////////////////////////////////////////
//	defines
///////////////////////////////////////////////////////////////////////////////

//#define ICON_HEIGHT 72
#define ICON_SPACING 36
//#define	ICON_HALF_HEIGHT	 (ICON_HEIGHT / 2)
//#define ICON_QUARTER_HEIGHT  (ICON_HEIGHT / 4)
#define ICON_TOP 230

//#define	ICON_WIDTH	80
#define	ICON_WIDTH	160
#define	ICON_HALF_WIDTH	(ICON_WIDTH / 2)

///////////////////////////////////////////////////////////////////////////////
//	typedefs
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//	globals
///////////////////////////////////////////////////////////////////////////////

extern	float	ref_laserRotation;
extern	void R_DrawAliasIcon (entity_t *ent);

///////////////////////////////////////////////////////////////////////////////
//	inventory_DrawChar
///////////////////////////////////////////////////////////////////////////////

/*
void inventory_DrawChar (int x, int y, char c)
{
	float	charWidth;	//	width of a single char in texture coordinates
	float	charHeight;
	float	width, height;
	float	left, right, top, bottom;
	int		charNum, row, column;

	if (c != '-')
	{
		charNum = c - 0x30;	//	only handles 0 - 9
		if (charNum < 0 || charNum > 9)
			return;
	}
	else
		charNum = 10;

	row = (int)(charNum / ICON_CHARS_PER_ROW);
	column = charNum - (int)(row * ICON_CHARS_PER_ROW);

    width = (float)(r_inventoryNumbers->width);
    height = (float)(r_inventoryNumbers->height);

	//	get texture coords
	charWidth = ICON_CHAR_WIDTH / width;
	charHeight = ICON_CHAR_HEIGHT / height;

	left = column * charWidth;
	right = left + charWidth;
	top = row * charHeight;
	bottom = top + charHeight;

    //bind our texture number.
	GL_Bind (r_inventoryNumbers->texnum);

	qglBegin(GL_QUADS);

	qglTexCoord2f (left, top);
	qglVertex2f (x, y);
	qglTexCoord2f (right, top);
	qglVertex2f (x + ICON_CHAR_WIDTH, y);
	qglTexCoord2f (right, bottom);
	qglVertex2f (x + ICON_CHAR_WIDTH, y + ICON_CHAR_HEIGHT);
	qglTexCoord2f (left, bottom);
	qglVertex2f (x, y + ICON_CHAR_HEIGHT);

	qglEnd();
}

///////////////////////////////////////////////////////////////////////////////
//	inventory_DrawNum
//
///////////////////////////////////////////////////////////////////////////////

void inventory_DrawNum (int x, int y, int num)
{
	char	str [16];
	int		i, len;

	itoa (num, str, 10);

	len = strlen (str);
	for (i = 0; i < len; i++)
	{
		inventory_DrawChar (x, y, str [i]);

		x += ICON_CHAR_WIDTH;
	}
}

///////////////////////////////////////////////////////////////////////////////
//	inventory_DrawBox
//
///////////////////////////////////////////////////////////////////////////////

void inventory_DrawBox (int x, int y, int w, int h, float alpha)
{
	qglColor4f (1.0, 1.0, 1.0, alpha);

	GL_Bind (r_inventoryTextures [r_newrefdef.episodeNum]->texnum);

	qglBegin (GL_QUADS);

	qglTexCoord2f (0, 0);
	qglVertex2f (x, y);

	qglTexCoord2f (0, 1);
	qglVertex2f (x + w, y);

	qglTexCoord2f (1, 1);
	qglVertex2f (x + w, y + h);

	qglTexCoord2f (1, 0);
	qglVertex2f (x, y + h);

	qglEnd ();
	qglColor4f (1.0, 1.0, 1.0, 1.0);
}
*/



/*
///////////////////////////////////////////////////////////////////////////////
//	onscreen_icons
///////////////////////////////////////////////////////////////////////////////
void GL_Onscreen_Icons_Display(void)
{
	int				 i, sx, sy, i2;
	entity_t		 ent;
  onscreen_icons_t icon;
	CVector			 origin;
	int				 numIcons;
	
    //return;

  numIcons = r_newrefdef.onscreen_icons_info.num_icons;

  if (numIcons <= 0) // any icons visible?
	  return;

	//	clear the zbuffer
	qglClear(GL_DEPTH_BUFFER_BIT);

  // left edge of screen, full height of screen
	//             x  y       width      height
  qglViewport (  0, 0, ICON_WIDTH, vid.height);

	qglMatrixMode(GL_PROJECTION);
	qglPushMatrix ();
	qglLoadIdentity ();
	
    // match this with viewport
    //         left       right      bottom  top
    qglOrtho  (   0, ICON_WIDTH, vid.height,   0, -9999, 9999);


	qglMatrixMode(GL_MODELVIEW);
	qglPushMatrix ();
    qglLoadIdentity ();


    sx = ICON_HALF_WIDTH;   // set x cemter at half viewport width
    sy = vid.height - ICON_QUARTER_HEIGHT; // y at bottom of screen


	origin.x = sx;
	origin.y = sy;
	origin.z = 0;

	//	write to Z buffer

	GL_SetState( GLSTATE_PRESET1 & ~GLSTATE_CULL_FACE_FRONT );
	
	GL_SetFunc( GLSTATE_DEPTH_FUNC, GL_LESS, -1 );

	qglShadeModel (GL_SMOOTH);

	//	draw the icon models
	for (i = 0; i < MAX_ONSCREEN_ICONS; i++)
	{
        icon = r_newrefdef.onscreen_icons_info.icons[i]; 
      
		//if (origin.y > clipTop && origin.y < clipBottom)
		//{
            // loop through both icons
            for (i2 = 0;i2 < 2;i2++)
            {

	          //origin.x = sx;
	          //origin.y = sy;
	          //origin.z = 0;

 			  if (icon.models[i2] != NULL)
			  {
				// set up an entity so we can draw the model
				memset (&ent, 0x00, sizeof (entity_t));

				ent.model = icon.models[i2];
				ent.origin = origin;

        // rotation
        if (i2 & 1)
          ent.angles.x += ref_laserRotation * 8; // rotate counter
        else
          ent.angles.x -= ref_laserRotation * 8; // rotate clockwise

        ent.angles.z = -90; // sit up nice and tall, fuckstick

				ent.frame = 1;
				ent.oldorigin = origin;
				ent.oldframe = 0;
				ent.backlerp = 0;
				ent.skinnum = 0;
///				ent.lightstyle = 0;

				ent.flags = RF_TRANSLUCENT | RF_MINLIGHT;
                //ent.flags |= RF_FULLBRIGHT;
                
                if (i2 & 1)
                  ent.flags |= RF_GLOW;

                ent.alpha = icon.alpha;  // set alpha


                ent.render_scale.Set(2.0,2.0,2.0);  // scale depends on viewport size
                //ent.render_scale.Set(1.0,1.0,1.0);  // scale depends on viewport size

				R_DrawAliasIcon (&ent);
			  }
              //else
              //  Com_Printf("icon %i  model %d null\n",i,i2);

            }
		//}

        if (icon.models[0] != NULL) // did we draw a model?
        {
		  // make room for the next icon
          origin.y -= ICON_HEIGHT;
        }
	}

	qglMatrixMode(GL_PROJECTION);
	qglPopMatrix ();
	qglMatrixMode(GL_MODELVIEW);
	qglPopMatrix ();

    qglViewport (0, 0, vid.width, vid.height);

	GL_SetFunc( GLSTATE_DEPTH_FUNC, GL_LEQUAL, -1 );

	qglCullFace (GL_FRONT);
}
*/



///////////////////////////////////////////////////////////////////////////////
//	onscreen_icons
///////////////////////////////////////////////////////////////////////////////
void GL_Onscreen_Icons_Display(void)
{
	int				 i, sx, sy, i2;
	entity_t		 ent;
  onscreen_icons_t icon;
	CVector			 origin;
	int				 numIcons;
	
  //return;  // TEMPORARY

  numIcons = r_newrefdef.onscreen_icons_info.num_icons;

  if (numIcons <= 0) // any icons visible?
	  return;

	
	qglClear(GL_DEPTH_BUFFER_BIT);  //	clear the zbuffer

  // left edge of screen, full height of screen
	//             x  y       width      height
  qglViewport (  0, 0, ICON_WIDTH, vid.height);

	qglMatrixMode(GL_PROJECTION);
	qglPushMatrix ();
	qglLoadIdentity ();
	
  // match this with viewport
  //       left       right      bottom  top
  qglOrtho(   0, ICON_WIDTH, vid.height,   0, -9999, 9999);

	qglMatrixMode(GL_MODELVIEW);
	qglPushMatrix ();
  qglLoadIdentity ();

  sx = ICON_HALF_WIDTH;         // set x center at half viewport width
	sy = vid.height - ICON_TOP;  	// start at TOP and work spacing DOWN


  //sy = vid.height - ICON_QUARTER_HEIGHT; // y at bottom of screen


	origin.x = sx;
	origin.y = sy;
	origin.z = 0;

	//	write to Z buffer
	GL_SetState( GLSTATE_PRESET1 & ~GLSTATE_CULL_FACE_FRONT );
	GL_SetFunc( GLSTATE_DEPTH_FUNC, GL_LESS, -1 );

	qglShadeModel (GL_SMOOTH);

	//	draw the icon models
	for (i = 0; i < MAX_ONSCREEN_ICONS; i++)
	{
    icon = r_newrefdef.onscreen_icons_info.icons[i]; 
      
    // loop through both icons
    for (i2 = 0;i2 < 2;i2++)
    {
      if (icon.models[i2] != NULL)
			{
				// set up an entity so we can draw the model
				memset (&ent, 0x00, sizeof (entity_t));

				ent.model = icon.models[i2];
				ent.origin = origin;

        // rotation
        if (i2 & 1)
          ent.angles.x += ref_laserRotation * 8; // rotate counter
        else
          ent.angles.x -= ref_laserRotation * 8; // rotate clockwise

        ent.angles.z = -90; // sit up nice and tall, fuckstick

				ent.frame     = 1;
				ent.oldorigin = origin;
				ent.oldframe  = 0;
				ent.backlerp  = 0;
				ent.skinnum   = 0;
        ent.alpha = icon.alpha;                         // set alpha
				ent.flags     = RF_TRANSLUCENT | RF_MINLIGHT;
      //ent.flags     = RF_FULLBRIGHT;
                
        if (i2 & 1)
          ent.flags |= RF_GLOW;  // glow the internal model

        ent.render_scale.Set(1.0,1.0,1.0);  // scale depends on viewport size

				R_DrawAliasIcon (&ent);
			}
    }

    //if (icon.models[0] != NULL) // did we draw a model?
    //{
			// work from TOP to bottom
			origin.y += ICON_SPACING;  // make room for the next icon

      //origin.y -= ICON_HEIGHT;  // make room for the next icon
    //}
	}

	qglMatrixMode(GL_PROJECTION);
	qglPopMatrix ();
	qglMatrixMode(GL_MODELVIEW);
	qglPopMatrix ();
  qglViewport (0, 0, vid.width, vid.height);  // reset viewport fullscreen

	GL_SetFunc( GLSTATE_DEPTH_FUNC, GL_LEQUAL, -1 );

	qglCullFace (GL_FRONT);
}

